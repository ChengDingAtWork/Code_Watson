import numpy as np
import os
from resnet1d import resnet_34
import tensorflow as tf
from keras import backend as K

x_train = np.random.rand(15000000,7201,1)
y_train = np.random.randint(2, size=15000000)
batch_size = 1024
nb_classes = 2
nb_epoch = 50

model = resnet_34(num_classes=nb_classes)
model.fit(x_train, y_train,
              batch_size=batch_size,
              nb_epoch=nb_epoch,
              validation_split = 0.2,
              shuffle=True,
              verbose=2,
              class_weight='auto')